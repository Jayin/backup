# -*- coding: utf-8 -*-
__author__ = 'jayin'

import exp1, exp1s

exp1s.main(5)

exp1.main(5)