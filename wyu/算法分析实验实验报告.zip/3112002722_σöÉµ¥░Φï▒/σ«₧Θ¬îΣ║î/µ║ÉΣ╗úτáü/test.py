# -*- coding: utf-8 -*-
__author__ = 'jayin'

from . import ex2, ex2s

ex2.main(3)
ex2s.main(3)

ex2.main(4)
ex2s.main(4)

