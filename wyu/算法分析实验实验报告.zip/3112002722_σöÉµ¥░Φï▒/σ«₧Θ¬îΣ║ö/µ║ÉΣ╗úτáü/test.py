# -*- coding: utf-8 -*-
__author__ = 'jayin'

import ex5

#-> 4
ex5.main(4,5,1,1)

#-> 7
ex5.main(4,5,1,2)

#-> 5
ex5.main(4,5,2,1)

#-> 8
ex5.main(4,5,2,4)

